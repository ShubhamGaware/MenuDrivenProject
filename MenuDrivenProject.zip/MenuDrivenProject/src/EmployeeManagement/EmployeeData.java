package EmployeeManagement;

public class EmployeeData {
	
	System.out.println();

}
